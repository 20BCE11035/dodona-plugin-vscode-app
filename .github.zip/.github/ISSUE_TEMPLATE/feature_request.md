---
name: Feature request
about: Request a new feature to be added to the plugin.
title: "[FEATURE] "
labels: 'feature :star:'
assignees: stijndcl

---

**Briefly describe the feature idea:**
_Describe your feature here, explain what it is and why it should be added._
