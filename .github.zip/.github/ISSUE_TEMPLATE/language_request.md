---
name: Language request
about: Request a new language to be supported by the plugin.
title: "[LANG] "
labels: 'enhancement :arrow_up:'
assignees: thepieterdc

---

**Language:**
- Name: [e.g. Brainfuck]